package es

import (
	_ "github.com/beego/beego/v2/core/logs/es"
)
