---
name: Bug Report
about: Create a report to help us improve
---

### What happened

### Expected behavior

### Steps to reproduce

#### reproducible code

#### manifest.yaml

### Versions
- Go:
- slack-go/slack:
